/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.numerical;

/**
 *
 * @author ASUS TUF GAMING
 */
public class Numerical {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
